export default {
  // baseUrl: 'https://api.leadpoint.ru/panel/',
  baseUrl: 'https://456a495e.ngrok.io/panel/',
  login: 'login',
  signup: 'signup',
  lead: 'lead',
  filter: 'lead/filter',
  logout: 'logout',
  cfg: 'cfg',
  callback: 'callback'
}
