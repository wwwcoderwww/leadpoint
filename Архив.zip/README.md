npm run dev

npm run build
